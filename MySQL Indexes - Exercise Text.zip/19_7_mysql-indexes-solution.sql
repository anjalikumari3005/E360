# MySQL Indexes - solution 1

ALTER TABLE employees

DROP INDEX i_hire_date;