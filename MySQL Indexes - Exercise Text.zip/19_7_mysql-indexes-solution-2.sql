# MySQL Indexes - solution 2

SELECT

    *

FROM

    salaries

WHERE

    salary > 89000;



CREATE INDEX i_salary ON salaries(salary);



SELECT

    *

FROM

    salaries

WHERE

    salary > 89000;