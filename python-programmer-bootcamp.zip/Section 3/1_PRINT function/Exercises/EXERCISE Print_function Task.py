# -*- coding: utf-8 -*-
"""
Spyder Editor

Print function.
"""

print('one',end=' ')
print('two',end=' ')
print('three',end=' ')
print('four',end=' ')
