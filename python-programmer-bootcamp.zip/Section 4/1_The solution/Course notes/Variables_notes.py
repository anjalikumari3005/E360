#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 09:42:38 2019

@author: Giles
"""

#x = 5
#
#y = 12
##
#z = x + y
##
#print(z)
#
#1x = 3
#new_variable = 9

#z = x - y
#
#a = 2.5
#b = 3.14159
#c = b * a**2
##
#radius = 2.5
#pi = 3.14159
#area_of_circle = pi * radius**2

#phrase_1 = 'The cat sat on the mat!'
#phrase_2 = 'And so did the dog!'
#phrase_3 = phrase_1 + ' ' + phrase_2

#user_input = int(input('How many apples do you have?\n >>> '))

#help()
while = 5