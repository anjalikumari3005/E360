# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 12:15:28 2019

@author: giles
"""

import greetings

greetings.hi_2()

greetings.hello()

greetings.hi('Alison')