#!/usr/bin/env python
# coding: utf-8

# # Exception Handling Question
# 
# Write a few lines of code that will open and read text file line by line to a variable. Use a try and except block to handle the event of the file not existing.

# In[ ]:




