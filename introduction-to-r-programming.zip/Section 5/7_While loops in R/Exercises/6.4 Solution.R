

# Write a while loop that sums all the numbers from 1 to n 

n <- 10
i <- 1
sum <- 0

while(i <= n){
  sum <- sum + i
  i <- i + 1
  print(sum)
}

