# The weather data we used in the last lesson was already almost tidy when we imported it. Please find a lot less tidy version in the resources for this lesson and go through the necessary steps to clean it.

# Note: read the documentation on the parse_number() function from the readr package, and try to use it when cleaning the data.

# Play around with the tb data, too; try to reproduce what we did in the lesson - you will need to do a little bit more tidying than we did together. Hint: if you are confused about what to do with the gender-age variables, try reading the documentation on the str_replace() function from the stringr package.