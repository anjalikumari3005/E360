# Requirements: the following vectors: the named atk object from the previous exercise.

# Extract the following values from the atk object:
  
#The 6-th value (can you do it in more than one way)
#All the values but the 2nd one
#Values 1, 3, 5, 7, and 9
#All the values but the 4th, 5th, and 6th
#All the values larger than 2000