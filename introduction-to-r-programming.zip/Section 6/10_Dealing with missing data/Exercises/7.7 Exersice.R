

## Using the employee_data_na.CSV file, please answer the following questions:

## 1. Are there NA values in the data at all?

## 2. Find out in which columns the NA values are?

## 3. Use the sum() function to find out how many missing values there are in total?

## 4. How about by variable?

## 5. Edit the observations 

## 6. Reload the data and delete the rows with missing values using the na.omit() function
