# Create a vector x storing the sequence 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20.

# Add 2 to it. Save the result into a variable called y.

# Multiply y by 3. Save that into a variable called z.

# Subtract 6 from z and divide the result by 3. Save what you get into a variable called answer.

# Print your answer variable.

#Try to do the entire operation in a single line of code. 

# What do you need to do to get the same result? 
# Why is that? 
# Do you notice anything about the operations? Do they follow a specific order; how are they carried out?