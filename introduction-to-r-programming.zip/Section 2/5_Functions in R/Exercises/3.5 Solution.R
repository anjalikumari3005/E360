

ls()

lvl <- c(8, 10, 10, 1, 10, 10, 8, 12, 1, 12)

sum(lvl)
mean(lvl)
median(lvl)
length(lvl)
sd(lvl)
round(sd(lvl))
print(round(sd(lvl))) # this doesn't look super easy to read -- we will learn a better way to
                      # do consecutive operations that doesn't involve nesting like this


