
# create a list which prints like this: 

# [[1]]
# [1]  1  3  5  7  9 11
#
# [[2]]
# [[2]][[1]]
# [1] "Happy Birthday"
#
# [[2]][[2]]
# [1] "Archery" 


# extract the numbers as a vector

# extract the phrase Happy Birthday as a vector

# extract the second item of the second list as a list

# extract the second list as a list

# extract the numbers item as a list

# add 2 to each element in the numbers item

# name the items in the list as "Numbers" and "Phrases"

# you can use the $ to extract named items of a list
# if you extract the numbers item from newList with the $, what other extraction method is this equivalent to?

# use the dollar sign to repeat the addition from above (add 2 to each element in the numbers list)

# add a new item called "Brands" to the list. It should contain the brands Kellogs, Nike, iPhone
# use either brackets or the dollar sign to do that

# remove the iPhone from the Brands item

# remove the Brands item from the list
