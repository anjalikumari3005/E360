# Requirements: the chess matrix from Exercise 11.

# Save the Piece column of the matrix as a vector.

# Create a factor from the vector.

# Organize the levels in the following way but do not order them: King, Queen, Rook, Bishop, Knight, Pawn.

# Rename the levels with just their initial letters. Order the levels in the way specified above.