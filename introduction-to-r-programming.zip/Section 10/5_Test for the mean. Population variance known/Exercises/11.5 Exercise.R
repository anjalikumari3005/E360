

# Using the data from the lesson, test the null hypothesis at 10% significance

# sample mean: $100,200
# population sd: $15,000
# standard error: $2,739
# sample size: 30
# z-score: -4.67 
# H0 (Glassdoor data): $113,000
# two-sided test

